export const productService = {
    getProductsUrl: () => 'https://showroomdepotcostume.com/wp-json/custom-api/v1/products',
  };