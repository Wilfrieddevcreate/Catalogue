import React from "react";

const phoneNumber = 22961790448;

const NumberPhone: React.FC = () => {
  return <div>{phoneNumber}</div>;
}

export default NumberPhone;
